package com.travel.load.Entity;

public enum AppUserRole {
    USER,
    ADMIN
}
